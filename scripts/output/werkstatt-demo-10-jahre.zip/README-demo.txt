Werkstatt-Verwaltung — Demo über 10 Schuljahre
================================================
Import: Daten → ZIP importieren
Datei: werkstatt-demo-10-jahre.zip
Die kleine Demo (werkstatt-demo.zip) bleibt daneben liegen.

Zeitraum: 2017/2018 T1 bis 2026/2027 T3 (30 Trimester)
Schüler: 176 (16 je Einschulungsjahr 2016–2026)
Aktive Werkstätten: 15
Archivierte Werkstätten: 9

2017/18 starten Stufe 5 und 6 im selben Band. Neue Stufen kommen dazu, ohne dass jede Stufe ein eigenes Band bekommt.
Die meisten Bänder gehören zwei Jahrgängen, manchmal dreien. Ab 2021/22 sind sechs Jahrgänge da (Stufe 5 bis 10),
auf vier geteilten Bändern. Wer noch nicht in Stufe 5 ist oder schon abgeschlossen hat, steht in keinem Band.

Drei Aussetzer, nur für das eine Trimester:
2017/18 T2 Stufe 6 (Klassenfahrt), 2021/22 T2 Stufe 8 (Praktikum), 2024/25 T1 Stufe 9 (Austausch).
2018/19 T2 fällt der Schulgarten wegen eines Wasserrohrbruchs aus, und Stufe 7 wählt mit den Jüngeren.
2025/26 T2 fallen die Prüfungswochen auf ein Band, Stufe 5 bis 7 teilen sich das erste.

Die Notiz jedes Trimesters erzählt, wer sich ein Band teilt und was sich an den Kursen geändert hat.
Kurse, die wegfallen, stehen in archived-workshops.csv
(Fotolabor, Computer-AG, Schulgarten, Töpfern, Siebdruck, Holz Grundlagen, Nähen Einsteiger, Schülerzeitung, Schach & Strategie).

2026-2027 T3 ist nur geplant: Bänder, Stufen und Kurse stehen. Die Wahl ist hochgeladen, eine Zuordnung gibt es nicht.
Wahl-Upload: 100 Dateien, 3184 Zeilen. Zuordnung für alle früheren Trimester.
