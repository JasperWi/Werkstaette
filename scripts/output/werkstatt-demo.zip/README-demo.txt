Werkstatt-Verwaltung Demo-Daten
================================
Import via App: Daten → ZIP importieren

Inhalt:
- 60 Schüler (3 Jahrgänge × 20), Einschulungsjahre 2023 / 2024 / 2025
  · Teilnahme hängt nur an den angehakten Bändern der Klassenstufe, nicht daran, ob der Jahrgang „die Schule verlassen“ hätte
  · 2025: in den Demo-Dateien erst ab 2025/26, weil die Stufe davor in keinem Band hängt. Haken setzen, dann ist er dabei
- 6 Trimester (2024/25 T1–T3, 2025/26 T1–T3)
- Trimester-Organisation (stufenBandAccess):
  · 2024/25 T1–T2: 2 Bänder — Band 1 nur Stufe 5, Band 2 nur Stufe 6
  · 2024/25 T3 und 2025/26 T1–T3: 3 Bänder — + Band 3 für Stufe 5 & 6 gemeinsam
- Trimester 1–5: Zuordnungen (2 oder 3 Bänder je nach Plan)
- trimester-plans.json: alle Trimester-Konfigurationen (Bänder, Wahlen, Kurse, Stufen-Zugriff)
- 2025/26 T3: nur Trimester-Plan (Kursangebot pro Band), keine Zuordnung, keine Wahl-Dateien
- Wahl-CSV je Band für die Trimester mit Zuordnung: Student, Klasse, Wahl 1, Wahl 2
- Wahl 1 und Wahl 2 sind über die Kurse verteilt; nur ein Teil der ersten Wahlen entspricht der späteren Zuordnung
- Die Klasse im Wahl-Upload ist die Klasse in diesem Trimester (nicht die spätere Schülerakte)

Einschulungsjahr-Logik (wie App):
- Stufe 5 in SJ 2024/25 → 2024; Stufe 6 → 2023; JG 2025 nur ab 2025/26 T1
- Maja Becker: bleibt in 6b, Einschulungsjahr 2024 unverändert (Sitzenbleiben)

Demo-Kanten:
- Film & Medien in T5 überbucht
- Möbelbau ohne überall erfüllte Holz-Voraussetzung
- Lustige Kommentare & uneinheitliche Priority-Scores
